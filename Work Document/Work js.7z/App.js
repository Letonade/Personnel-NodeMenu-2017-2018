
/*
** On se fait un petit menu en Js.
*/
var MyLib = require('./MyLib');
var MyRun = require('./MyRun');

// Main menu
showMain = function () {
    // Création du tableau de texte
    let txt =[];
    txt.push('Start Firefox')
    txt.push("Go to sub");
    txt.push("Exit");
    // Affichage du menu
    MyLib.ME(txt);
    MyLib.QE("You'r choice ?",showMain,[MyRun.firefox,showSub,process.exit]);
}

// Sub bro
showSub = function () {
    // Création du tableau de texte
    let txt =[];
    txt.push("Go to Main");
    txt.push("Exit");
    // Affichage du menu
    MyLib.ME(txt);
    MyLib.QE("You'r choice ?",showSub,[showMain,process.exit]);
}

showMain();

//   /$$$$$$   /$$$$$$  /$$   /$$ /$$$$$$$$ /$$$$$$$$
//  /$$__  $$ /$$__  $$| $$$ | $$|__  $$__/| $$_____/
// | $$  \__/| $$  \ $$| $$$$| $$   | $$   | $$
// | $$      | $$  | $$| $$ $$ $$   | $$   | $$$$$
// | $$      | $$  | $$| $$  $$$$   | $$   | $$__/
// | $$    $$| $$  | $$| $$\  $$$   | $$   | $$
// |  $$$$$$/|  $$$$$$/| $$ \  $$   | $$   | $$$$$$$$
//  \______/  \______/ |__/  \__/   |__/   |________/
//
//   /$$$$$$   /$$$$$$  /$$$$$$$  /$$$$$$$$ /$$   /$$ /$$$$$$$$ /$$$$$$ /$$   /$$
//  /$$__  $$ /$$__  $$| $$__  $$| $$_____/| $$$ | $$|__  $$__/|_  $$_/| $$$ | $$
// | $$  \__/| $$  \ $$| $$  \ $$| $$      | $$$$| $$   | $$     | $$  | $$$$| $$
// | $$      | $$  | $$| $$$$$$$/| $$$$$   | $$ $$ $$   | $$     | $$  | $$ $$ $$
// | $$      | $$  | $$| $$__  $$| $$__/   | $$  $$$$   | $$     | $$  | $$  $$$$
// | $$    $$| $$  | $$| $$  \ $$| $$      | $$\  $$$   | $$     | $$  | $$\  $$$
// |  $$$$$$/|  $$$$$$/| $$  | $$| $$$$$$$$| $$ \  $$   | $$    /$$$$$$| $$ \  $$
//  \______/  \______/ |__/  |__/|________/|__/  \__/   |__/   |______/|__/  \__/

