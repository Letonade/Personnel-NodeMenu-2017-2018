
/*
** On se fait une ptite lib du menu.
*/

var readline = require('readline'),
    menu;

// focntion enjoliveur de menu
MenuEnhancer = function ([...z]){
    // Variable d'accumulation
    let text;
    // Clear screen
    process.stdout.write('\033c');
    // Entête
    text = "\n_- MENU -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_\n\n";
    // Boucle de remplissage des options
    for (var i = 0; i <= z.length - 1; i++) {
        text += `${i+1}. ${z[i]}\n`;
    };
    // Footer
    return text += "\n-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_\n";
};
LogMenuEnhancer = function (z){console.log(MenuEnhancer(z));}

Questionary = function (quest,deaf,[...z]){
    // Vérification en cas de double menu
    if(menu) menu.close();
    // Créer une instance d'interface readline
    menu = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    // la question
    menu.question(quest, function(input) {
        if (input-1 <= z.length -1 && input-1 >= 0) {z[input-1]();}
        else deaf();
    });
}

// Export des Module
module.exports = {
    ME : LogMenuEnhancer,
    QE : Questionary
};

//   /$$$$$$   /$$$$$$  /$$   /$$ /$$$$$$$$ /$$$$$$$$
//  /$$__  $$ /$$__  $$| $$$ | $$|__  $$__/| $$_____/
// | $$  \__/| $$  \ $$| $$$$| $$   | $$   | $$
// | $$      | $$  | $$| $$ $$ $$   | $$   | $$$$$
// | $$      | $$  | $$| $$  $$$$   | $$   | $$__/
// | $$    $$| $$  | $$| $$\  $$$   | $$   | $$
// |  $$$$$$/|  $$$$$$/| $$ \  $$   | $$   | $$$$$$$$
//  \______/  \______/ |__/  \__/   |__/   |________/
//
//   /$$$$$$   /$$$$$$  /$$$$$$$  /$$$$$$$$ /$$   /$$ /$$$$$$$$ /$$$$$$ /$$   /$$
//  /$$__  $$ /$$__  $$| $$__  $$| $$_____/| $$$ | $$|__  $$__/|_  $$_/| $$$ | $$
// | $$  \__/| $$  \ $$| $$  \ $$| $$      | $$$$| $$   | $$     | $$  | $$$$| $$
// | $$      | $$  | $$| $$$$$$$/| $$$$$   | $$ $$ $$   | $$     | $$  | $$ $$ $$
// | $$      | $$  | $$| $$__  $$| $$__/   | $$  $$$$   | $$     | $$  | $$  $$$$
// | $$    $$| $$  | $$| $$  \ $$| $$      | $$\  $$$   | $$     | $$  | $$\  $$$
// |  $$$$$$/|  $$$$$$/| $$  | $$| $$$$$$$$| $$ \  $$   | $$    /$$$$$$| $$ \  $$
//  \______/  \______/ |__/  |__/|________/|__/  \__/   |__/   |______/|__/  \__/

